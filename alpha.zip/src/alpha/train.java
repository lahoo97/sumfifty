package alpha;

public class train {
	String trainName;
	String departure;
	String date;
	String arrival;
	int totalSeat;
	int trainNumber;
	
	public void update(String trainName, String departure, String arrival, int totalSeat, int trainNumber, String date){
		
	}
	
	public void seatCount(int totalSeat, boolean seatState){
		
	}
	

}
