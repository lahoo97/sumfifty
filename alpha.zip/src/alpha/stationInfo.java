package alpha;

public class stationInfo {
	
	String stationName;
	double stationLat;
	double stationLon;
	
	public void sendInfo(String sationName, double stationLat, double stationLon){
		
	}

}
