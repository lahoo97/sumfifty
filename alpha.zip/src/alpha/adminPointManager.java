package alpha;

public class adminPointManager {
	
	admin userPoint = new admin();
	
	private void pointAdd(){
		
	}
	
	private void pointReset(){
		
	}
	
	private void pointDelete(){
		
	}

}
