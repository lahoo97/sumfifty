package alpha;

public class mainSystem {
	
	seatSystem seatSystem = new seatSystem();
	stationInfo stationInfo = new stationInfo();
	LocationSystem LocationSystem = new LocationSystem();

	
	public void requestSettingAlert(){
		
	}
	
	public void compareLocation(double stationLat, double stationLon, double lat, double lon){
		
	}
	
	
}
