package alpha;

public class LocationSystem {
	
	boolean isGPSEnable;
	boolean isNetworkEnabled;
	double lat;
	double lon;
	
	public void sendLocation (double lat, double lon, String userName, boolean seatState){
		
	}
	
	private void getLocation(){
		
	}
	
}
