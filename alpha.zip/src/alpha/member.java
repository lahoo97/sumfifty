package alpha;

public class member {
	
	private String userID;
	private String userPasswort;
	String userName;
	
	public void add(String userID, String userPassword, String userName){
		
	}
	
	public void delete(String userName, String userPassword){
		
	}
	
	private void getuserID(){
		
	}
	private String setuserID(String userID){
		return userID;
	}
	
	private void getuserPassword(String userPassword){
		
	}
	private String setuserPassword(String userPassword){
		return userPassword;
	}
	
	public void login(String userID, String userPassword){
		
	}

}
