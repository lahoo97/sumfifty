package alpha;

public class User {
	int boxNumber;
	int seatNumber;
	boolean seatState;
	boolean exist;
	boolean seatEmpty;
	
	public void seat(String trainName, int boxNumber, int seatNumber){
		
	}
	
	public boolean setSeat(boolean seatState){
		return true;
	}
	
	public void update(String trainName, int boxNumber, int seatNumber){
		
	
	}
	
	public void seatInfo(boolean exist, boolean seatEmpty, int boxNumber, int seatNumber){
		
	}

}
