package alpha;

public class userPoint {
	
	private int Point =0;
	private int totalPoint = 0;
	
	private int userPoint(){
		return Point;
	}
	
	private int totalPoint(){
		return totalPoint;
		
	}
	
	

}
