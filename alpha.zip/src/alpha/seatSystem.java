package alpha;

public class seatSystem {
	
	int seatnum;
	User[] seat  = new User[0];
	int boxNumber;
	
	public void update(String trainName, int boxNumber, int seatNumber){
		
	}
	
	public void emptySeat(){
		
	}

}
