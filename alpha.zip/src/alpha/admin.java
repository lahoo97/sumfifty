package alpha;

public class admin {
	
	private String adminID;
	private String adminPassword;
	String adminName;
	
	private void accuracyTest(boolean exist, boolean seatEmpty, int boxNumber, int seatNumber){
		
	}
	
	public void emptySeat(){
		
	}
	
	public void fullSeat(){
		
	}
	

}
